// affichage.h du projet SUDOKU
// Contient les fonctions liées à l'affichage

// Franck.Quessette@uvsq.fr
// Novembre 2016

#include "sudoku.h"

void initialiser_affichage();

void afficher_sudoku(SUDOKU S);
